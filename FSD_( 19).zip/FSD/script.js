/* ==========================================================================
   1. MASTER DATASETS (DISHES, VENDORS, GALLERY)
   ========================================================================== */
const DISHES = [
  // Starters
  { id: 's1', name: 'Paneer Tikka Angara', course: 'Starters', price: 65, diet: 'Veg', prep: 'Tandoor' },
  { id: 's2', name: 'Crispy Corn Salt & Pepper', course: 'Starters', price: 50, diet: 'Jain', prep: 'Wok' },
  { id: 's3', name: 'Hara Bhara Kebab', course: 'Starters', price: 55, diet: 'Veg', prep: 'Griddle' },
  { id: 's4', name: 'Chicken Malai Tikka', course: 'Starters', price: 90, diet: 'Non-Veg', prep: 'Tandoor' },
  { id: 's5', name: 'Veg Spring Rolls', course: 'Starters', price: 45, diet: 'Veg', prep: 'Fried' },
  { id: 's6', name: 'Jain Banana Cutlets', course: 'Starters', price: 55, diet: 'Jain', prep: 'Griddle' },

  // Mains
  { id: 'm1', name: 'Paneer Butter Masala', course: 'Mains', price: 95, diet: 'Veg', prep: 'Gravy' },
  { id: 'm2', name: 'Dal Makhani (24-Hr Slow Cooked)', course: 'Mains', price: 80, diet: 'Veg', prep: 'Signature' },
  { id: 'm3', name: 'Subz Diwani Handi', course: 'Mains', price: 75, diet: 'Veg', prep: 'Kadhai' },
  { id: 'm4', name: 'Butter Chicken Delhi Style', course: 'Mains', price: 130, diet: 'Non-Veg', prep: 'Signature' },
  { id: 'm5', name: 'Jain Palak Paneer (No Onion/Garlic)', course: 'Mains', price: 95, diet: 'Jain', prep: 'Satvik' },
  { id: 'm6', name: 'Chole Amritsari', course: 'Mains', price: 70, diet: 'Veg', prep: 'Punjabi' },

  // Breads & Rice
  { id: 'b1', name: 'Assorted Butter Naan & Roti Basket', course: 'Breads', price: 40, diet: 'Jain', prep: 'Live Tandoor' },
  { id: 'b2', name: 'Subz Dum Biryani with Raita', course: 'Breads', price: 65, diet: 'Veg', prep: 'Dum' },
  { id: 'b3', name: 'Jeera Peas Pulao', course: 'Breads', price: 45, diet: 'Jain', prep: 'Steamed' },
  { id: 'b4', name: 'Hyderabadi Chicken Biryani', course: 'Breads', price: 110, diet: 'Non-Veg', prep: 'Dum' },

  // Desserts
  { id: 'd1', name: 'Hot Gulab Jamun (2 pcs)', course: 'Desserts', price: 40, diet: 'Jain', prep: 'Classic' },
  { id: 'd2', name: 'Moong Dal Halwa', course: 'Desserts', price: 55, diet: 'Jain', prep: 'Ghee Roast' },
  { id: 'd3', name: 'Vanilla & Chocolate Ice Cream', course: 'Desserts', price: 40, diet: 'Jain', prep: 'Chilled' },
  { id: 'd4', name: 'Rasmalai Saffron Bowl', course: 'Desserts', price: 60, diet: 'Jain', prep: 'Royal' },

  // Live Counters
  { id: 'l1', name: 'Old Delhi Chaat Live Counter', course: 'LiveCounters', price: 4500, diet: 'Veg', prep: 'Flat Station Fee', isFlat: true },
  { id: 'l2', name: 'Italian Live Pasta & Garlic Bread', course: 'LiveCounters', price: 5500, diet: 'Veg', prep: 'Flat Station Fee', isFlat: true },
  { id: 'l3', name: 'Ice Cream Teppanyaki Roll Station', course: 'LiveCounters', price: 6000, diet: 'Jain', prep: 'Flat Station Fee', isFlat: true }
];

const VENDORS = [
  {
    id: 'v1',
    name: 'Royal Feast Caterers',
    rating: 4.8,
    reviews: 142,
    minGuests: 50,
    multiplier: 1.00,
    fssai: 'FSSAI Gold #11220045',
    specialty: 'College Fests & Grand Banquets',
    staffRatio: '1 Server per 15 Guests',
    crockery: 'Bone China & Copper Chafers'
  },
  {
    id: 'v2',
    name: 'Spice Symphony Events',
    rating: 4.6,
    reviews: 98,
    minGuests: 50,
    multiplier: 0.93,
    fssai: 'FSSAI Verified #11220089',
    specialty: 'Budget Student & Corporate Buffets',
    staffRatio: '1 Server per 20 Guests',
    crockery: 'Melamine & Stainless Buffet'
  },
  {
    id: 'v3',
    name: 'Saffron & Salt Hospitality',
    rating: 4.9,
    reviews: 215,
    minGuests: 100,
    multiplier: 1.14,
    fssai: 'FSSAI Platinum #11220112',
    specialty: 'Luxury Weddings & Live Counters',
    staffRatio: '1 Server per 10 Guests',
    crockery: 'Imported Porcelain & Live Chefs'
  },
  {
    id: 'v4',
    name: 'CampusBite Bulk Kitchens',
    rating: 4.5,
    reviews: 76,
    minGuests: 80,
    multiplier: 0.88,
    fssai: 'FSSAI Verified #11220304',
    specialty: 'High-Volume Fest & Hackathon Meals',
    staffRatio: '1 Server per 25 Guests',
    crockery: 'Eco-Areca & Buffet Setup'
  },
  {
    id: 'v5',
    name: 'Jainam Pure Satvik Caterers',
    rating: 4.9,
    reviews: 164,
    minGuests: 50,
    multiplier: 1.04,
    fssai: '100% Veg/Jain Kitchen #11220510',
    specialty: 'Dedicated Jain & Pure Veg Events',
    staffRatio: '1 Server per 15 Guests',
    crockery: 'Dedicated Satvik Utensils'
  }
];

const GALLERY_ITEMS = [
  {
    id: 'g1',
    title: 'Annual TechFest Gala Dinner (320 Guests)',
    category: 'College Fest',
    borderClass: 'gallery-border-college',
    vendor: 'Royal Feast Caterers',
    cost: '₹430 / plate',
    bg: 'linear-gradient(135deg, #b45309, #78350f)',
    emoji: '🎓🍛',
    details: 'Served 320 engineering students with zero queue bottlenecks using 4 parallel buffet islands, Paneer Tikka, Dal Makhani, Biryani, and Live Chaat.'
  },
  {
    id: 'g2',
    title: 'Royal Courtyard Wedding Reception (450 Guests)',
    category: 'Wedding',
    borderClass: 'gallery-border-wedding',
    vendor: 'Saffron & Salt Hospitality',
    cost: '₹780 / plate',
    bg: 'linear-gradient(135deg, #9d174d, #4c0519)',
    emoji: '💍✨',
    details: 'Full royal spread featuring 4 live counters, separate Jain kitchen counter, saffron rasmalai, and uniformed hospitality stewards.'
  },
  {
    id: 'g3',
    title: 'FinTech Product Launch Summit (120 Guests)',
    category: 'Corporate',
    borderClass: 'gallery-border-corporate',
    vendor: 'Spice Symphony Events',
    cost: '₹490 / plate',
    bg: 'linear-gradient(135deg, #1e3a8a, #0f172a)',
    emoji: '💼🥗',
    details: 'Executive working lunch with gourmet starters, live Italian pasta bar, and zero-plastic eco-tableware.'
  },
  {
    id: 'g4',
    title: 'Milestone 21st Birthday Bash (80 Guests)',
    category: 'Birthday',
    borderClass: 'gallery-border-birthday',
    vendor: 'Royal Feast Caterers',
    cost: '₹520 / plate',
    bg: 'linear-gradient(135deg, #047857, #064e3b)',
    emoji: '🎂🍨',
    details: 'Included Ice Cream Teppanyaki roll counter, crispy starters, and customized dessert platters.'
  },
  {
    id: 'g5',
    title: 'Department Farewell Banquet (150 Guests)',
    category: 'College Fest',
    borderClass: 'gallery-border-college',
    vendor: 'CampusBite Bulk Kitchens',
    cost: '₹395 / plate',
    bg: 'linear-gradient(135deg, #d97706, #78350f)',
    emoji: '🎉🍽️',
    details: 'Student-budget friendly 7-course buffet with +10% buffer cushion that ensured hot second servings for everyone.'
  },
  {
    id: 'g6',
    title: 'Pure Jain Silver Jubilee Celebration (200 Guests)',
    category: 'Wedding',
    borderClass: 'gallery-border-wedding',
    vendor: 'Jainam Pure Satvik Caterers',
    cost: '₹560 / plate',
    bg: 'linear-gradient(135deg, #be185d, #831843)',
    emoji: '🟠🌿',
    details: 'Prepared in a certified 100% onion-garlic-free kitchen with separate vessels and traditional brass service.'
  }
];

/* ==========================================================================
   2. APPLICATION STATE & INITIALIZATION
   ========================================================================== */
let state = {
  eventType: 'College Fest / Farewell',
  eventTheme: 'college',
  guests: 100,
  veg: 70,
  nonVeg: 20,
  jain: 10,
  activeCourse: 'Starters',
  selectedDishIds: ['s1', 's3', 'm1', 'm2', 'm3', 'b1', 'b2', 'd1', 'd3'],
  selectedVendorIds: ['v1', 'v2'],
  selectedRating: 5,
  savedQuotes: JSON.parse(localStorage.getItem('feastflow_quotes') || '[]'),
  reviews: [
    {
      name: 'Aarav Kulkarni (Fest Coordinator, COEP)',
      vendor: 'Royal Feast Caterers',
      event: 'College Fest / Farewell',
      rating: 5,
      comment: 'Booked for 180 students. The live per-plate calculator matched the final invoice to the rupee, and the +10% buffer saved us when extra alumni showed up!'
    },
    {
      name: 'Sneha Nair (HR Lead, CloudScale)',
      vendor: 'Spice Symphony Events',
      event: 'Corporate Summit',
      rating: 5,
      comment: 'Side-by-side comparison helped us get committee approval in 15 minutes using the PDF quote export. Punctual setup and hygienic packaging.'
    },
    {
      name: 'Chirag Shah (Host)',
      vendor: 'Jainam Pure Satvik Caterers',
      event: 'Birthday Party',
      rating: 5,
      comment: 'Finding strict Jain segregation with transparent pricing is usually a headache. FeastFlow made tasting and booking effortless.'
    },
    {
      name: 'Meera Deshmukh (Cultural Secretary)',
      vendor: 'CampusBite Bulk Kitchens',
      event: 'College Fest / Farewell',
      rating: 4,
      comment: 'Great value for college budgets. Starters stayed hot throughout the 3-hour farewell dinner.'
    }
  ]
};

window.addEventListener('DOMContentLoaded', () => {
  renderDishes();
  recalculateQuote();
  renderVendors();
  renderComparisonTable();
  renderGallery('All');
  renderReviews();
  updateSavedCount();
});

/* ==========================================================================
   3. EVENT THEME & QUOTE CALCULATOR LOGIC
   ========================================================================== */
function selectEventType(btn) {
  document.querySelectorAll('#eventTypeGroup .pill').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');

  state.eventType = btn.dataset.event;
  state.eventTheme = btn.dataset.theme;

  applyEventThemeBorders(state.eventTheme, state.eventType);
  recalculateQuote();
}

function applyEventThemeBorders(theme, eventLabel) {
  const wrapper = document.getElementById('calculatorWrapper');
  const controlsCard = document.getElementById('builderControlsCard');
  const activeBadge = document.getElementById('activeEventBadge');
  const quoteTag = document.getElementById('quoteEventTag');

  // Update outer section border & subtle background gradient per event type
  const bgMap = {
    college: 'bg-pattern-soft',
    wedding: 'bg-gradient-wedding',
    corporate: 'bg-gradient-corporate',
    birthday: 'bg-gradient-birthday'
  };
  wrapper.className = `section-box border-theme-${theme} ${bgMap[theme] || 'bg-pattern-soft'}`;

  // Update left border color of controls card
  const colorMap = {
    college: '#d97706',
    wedding: '#be185d',
    corporate: '#1d4ed8',
    birthday: '#059669'
  };
  controlsCard.style.borderLeftColor = colorMap[theme] || '#d97706';

  // Update badge styles
  activeBadge.className = `event-pill-badge badge-${theme}`;
  activeBadge.textContent = eventLabel;

  quoteTag.className = `event-pill-badge badge-${theme}`;
  quoteTag.textContent = eventLabel;
}

function handleGuestSlider(val) {
  const total = parseInt(val, 10);
  state.guests = total;
  state.nonVeg = Math.round(total * 0.2);
  state.jain = Math.round(total * 0.1);
  state.veg = total - state.nonVeg - state.jain;

  document.getElementById('vegCount').value = state.veg;
  document.getElementById('nonVegCount').value = state.nonVeg;
  document.getElementById('jainCount').value = state.jain;
  document.getElementById('guestDisplay').textContent = `${total} Guests`;

  recalculateQuote();
  renderVendors();
  renderComparisonTable();
}

function syncDietSplit() {
  const veg = Math.max(0, parseInt(document.getElementById('vegCount').value || 0, 10));
  const nonVeg = Math.max(0, parseInt(document.getElementById('nonVegCount').value || 0, 10));
  const jain = Math.max(0, parseInt(document.getElementById('jainCount').value || 0, 10));
  let sum = veg + nonVeg + jain;

  if (sum < 25) sum = 25;
  if (sum > 500) {
    showToast('Maximum guest capacity is 500 guests.');
    return;
  }

  state.veg = veg;
  state.nonVeg = nonVeg;
  state.jain = jain;
  state.guests = sum;

  document.getElementById('guestSlider').value = Math.min(500, Math.max(50, sum));
  document.getElementById('guestDisplay').textContent = `${sum} Guests`;

  recalculateQuote();
  renderVendors();
  renderComparisonTable();
}

function switchCourseTab(course, btn) {
  state.activeCourse = course;
  document.querySelectorAll('.course-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  renderDishes();
}

function renderDishes() {
  const grid = document.getElementById('dishGrid');
  const filtered = DISHES.filter(d => d.course === state.activeCourse);

  grid.innerHTML = filtered.map(d => {
    const isSel = state.selectedDishIds.includes(d.id);
    const dotClass = d.diet === 'Non-Veg' ? 'dot-nonveg' : (d.diet === 'Jain' ? 'dot-jain' : 'dot-veg');
    const priceLabel = d.isFlat ? `₹${d.price.toLocaleString('en-IN')} flat` : `₹${d.price}/plate`;

    return `
      <div class="dish-card ${isSel ? 'selected' : ''}" onclick="toggleDish('${d.id}')">
        <div>
          <div class="dish-title"><span class="diet-dot ${dotClass}"></span>${d.name}</div>
          <div class="dish-meta">${d.diet} • ${d.prep}</div>
        </div>
        <div class="text-right">
          <div class="dish-price">${priceLabel}</div>
          <div class="dish-status">${isSel ? '✅ Added' : '+ Add'}</div>
        </div>
      </div>
    `;
  }).join('');

  ['Starters', 'Mains', 'Breads', 'Desserts', 'LiveCounters'].forEach(c => {
    const count = DISHES.filter(d => d.course === c && state.selectedDishIds.includes(d.id)).length;
    const el = document.getElementById(`count-${c}`);
    if (el) el.textContent = count;
  });
}

function toggleDish(id) {
  if (state.selectedDishIds.includes(id)) {
    if (state.selectedDishIds.length <= 2) {
      showToast('Please keep at least 2 menu items selected.');
      return;
    }
    state.selectedDishIds = state.selectedDishIds.filter(item => item !== id);
  } else {
    state.selectedDishIds.push(id);
  }
  renderDishes();
  recalculateQuote();
  renderVendors();
  renderComparisonTable();
}

function resetDefaultMenu() {
  state.selectedDishIds = ['s1', 's3', 'm1', 'm2', 'm3', 'b1', 'b2', 'd1', 'd3'];
  renderDishes();
  recalculateQuote();
  renderVendors();
  renderComparisonTable();
  showToast('Menu reset to balanced banquet package.');
}

function loadDemoPreset() {
  state.eventType = 'College Fest / Farewell';
  state.eventTheme = 'college';
  state.guests = 150;
  state.veg = 100;
  state.nonVeg = 35;
  state.jain = 15;
  state.selectedDishIds = ['s1', 's4', 'm1', 'm2', 'm4', 'b1', 'b2', 'd1', 'd4', 'l1'];

  document.getElementById('guestSlider').value = 150;
  document.getElementById('guestDisplay').textContent = '150 Guests';
  document.getElementById('vegCount').value = 100;
  document.getElementById('nonVegCount').value = 35;
  document.getElementById('jainCount').value = 15;

  applyEventThemeBorders('college', state.eventType);
  renderDishes();
  recalculateQuote();
  renderVendors();
  renderComparisonTable();
  showToast('⚡ Loaded 150-Guest College Farewell Demo Package!');
}

function calculateQuoteMetrics(vendorMultiplier = 1.0) {
  const selectedObjects = DISHES.filter(d => state.selectedDishIds.includes(d.id));
  const perPlateDishSum = selectedObjects.filter(d => !d.isFlat).reduce((acc, d) => acc + d.price, 0);
  const liveStationFee = selectedObjects.filter(d => d.isFlat).reduce((acc, d) => acc + d.price, 0);

  let discountPct = 0;
  if (state.guests >= 200) discountPct = 10;
  else if (state.guests >= 100) discountPct = 5;

  document.getElementById('discountBadge').textContent = `${discountPct}% Volume Discount`;

  const adjustedPlateRate = Math.round(perPlateDishSum * vendorMultiplier);
  const baseSubtotal = adjustedPlateRate * state.guests;
  const dietSegregationFee = (state.nonVeg * 85) + (state.jain * 25);
  const discountAmount = Math.round(baseSubtotal * (discountPct / 100));
  const includeBuffer = document.getElementById('bufferToggle').checked;
  const bufferAmount = includeBuffer ? Math.round((baseSubtotal - discountAmount) * 0.10) : 0;

  const preTaxTotal = baseSubtotal + dietSegregationFee + liveStationFee - discountAmount + bufferAmount;
  const taxAndService = Math.round(preTaxTotal * 0.05);
  const grandTotal = preTaxTotal + taxAndService;
  const effectivePerPlate = Math.round(grandTotal / state.guests);

  return {
    selectedObjects,
    baseSubtotal,
    dietSegregationFee,
    liveStationFee,
    discountPct,
    discountAmount,
    bufferAmount,
    taxAndService,
    grandTotal,
    effectivePerPlate
  };
}

function recalculateQuote() {
  const q = calculateQuoteMetrics(1.0);
  const fmt = n => '₹' + n.toLocaleString('en-IN');

  document.getElementById('perPlatePrice').textContent = fmt(q.effectivePerPlate);
  document.getElementById('grandTotalPrice').textContent = fmt(q.grandTotal);
  document.getElementById('sumGuests').textContent = state.guests;
  document.getElementById('sumBase').textContent = fmt(q.baseSubtotal);
  document.getElementById('sumDiet').textContent = '+' + fmt(q.dietSegregationFee);
  document.getElementById('sumLive').textContent = '+' + fmt(q.liveStationFee);
  document.getElementById('sumDiscPct').textContent = q.discountPct + '%';
  document.getElementById('sumDisc').textContent = '-' + fmt(q.discountAmount);
  document.getElementById('sumBuffer').textContent = '+' + fmt(q.bufferAmount);
  document.getElementById('sumTax').textContent = '+' + fmt(q.taxAndService);
  document.getElementById('sumFinal').textContent = fmt(q.grandTotal);

  document.getElementById('escrow1').textContent = fmt(Math.round(q.grandTotal * 0.20));
  document.getElementById('escrow2').textContent = fmt(Math.round(q.grandTotal * 0.50));
  document.getElementById('escrow3').textContent = fmt(Math.round(q.grandTotal * 0.30));

  const names = q.selectedObjects.map(d => d.name).join(', ');
  document.getElementById('selectedDishesSummary').innerHTML = `<strong>Selected Menu (${q.selectedObjects.length} items):</strong> ${names}`;
}

/* ==========================================================================
   4. VENDOR DIRECTORY & SIDE-BY-SIDE COMPARISON
   ========================================================================== */
function renderVendors() {
  const grid = document.getElementById('vendorGrid');
  grid.innerHTML = VENDORS.map(v => {
    const metrics = calculateQuoteMetrics(v.multiplier);
    const isCompared = state.selectedVendorIds.includes(v.id);
    return `
      <div class="card vendor-card ${isCompared ? 'comparing' : ''}">
        <div>
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.5rem;">
            <span class="vendor-badge">✔ ${v.fssai}</span>
            <strong>⭐ ${v.rating} (${v.reviews})</strong>
          </div>
          <h3 style="margin-bottom:0.25rem;">${v.name}</h3>
          <p class="muted-small" style="margin-bottom:0.75rem;">${v.specialty} • Min ${v.minGuests} guests</p>
          <div class="vendor-price-box">
            <div class="muted-small">Quote for Your ${state.guests}-Guest Menu</div>
            <div style="font-size:1.28rem; font-weight:800; color:var(--primary-dark);">
              ₹${metrics.effectivePerPlate}/plate 
              <span style="font-size:0.84rem; font-weight:600; color:var(--secondary);">(₹${metrics.grandTotal.toLocaleString('en-IN')} total)</span>
            </div>
          </div>
        </div>
        <div class="two-col-grid" style="gap:0.5rem;">
          <button class="btn ${isCompared ? 'btn-primary' : 'btn-outline'} btn-sm" onclick="toggleVendorCompare('${v.id}')">
            ${isCompared ? '✓ Comparing' : '+ Compare'}
          </button>
          <button class="btn btn-secondary btn-sm" onclick="openTastingModal('${v.name}')">📅 Book Tasting</button>
        </div>
      </div>
    `;
  }).join('');
}

function toggleVendorCompare(id) {
  if (state.selectedVendorIds.includes(id)) {
    if (state.selectedVendorIds.length <= 1) {
      showToast('Keep at least 1 vendor in the comparison table.');
      return;
    }
    state.selectedVendorIds = state.selectedVendorIds.filter(v => v !== id);
  } else {
    if (state.selectedVendorIds.length >= 3) {
      showToast('You can compare up to 3 vendors side-by-side.');
      return;
    }
    state.selectedVendorIds.push(id);
  }
  renderVendors();
  renderComparisonTable();
}

function resetComparison() {
  state.selectedVendorIds = ['v1', 'v2'];
  renderVendors();
  renderComparisonTable();
  showToast('Comparison table reset.');
}

function renderComparisonTable() {
  const selected = VENDORS.filter(v => state.selectedVendorIds.includes(v.id));
  document.getElementById('compareCount').textContent = selected.length;
  const table = document.getElementById('compareTable');

  const headers = `<tr><th>Comparison Parameter</th>${selected.map(v => `<th>${v.name}<br><span style="font-weight:400; font-size:0.8rem;">⭐ ${v.rating} (${v.reviews} reviews)</span></th>`).join('')}</tr>`;

  const rows = [
    { label: 'Effective Per-Plate Rate', fn: v => `<strong>₹${calculateQuoteMetrics(v.multiplier).effectivePerPlate} / plate</strong>` },
    { label: `Total Estimate (${state.guests} Guests)`, fn: v => `<strong class="highlight-text">₹${calculateQuoteMetrics(v.multiplier).grandTotal.toLocaleString('en-IN')}</strong>` },
    { label: 'Minimum Guest Threshold', fn: v => `${v.minGuests} Guests` },
    { label: 'FSSAI Hygiene Certification', fn: v => v.fssai },
    { label: 'Service Staff Ratio', fn: v => v.staffRatio },
    { label: 'Crockery & Chafing Setup', fn: v => v.crockery },
    { label: 'Direct Action', fn: v => `<button class="btn btn-accent btn-sm" onclick="openTastingModal('${v.name}')">📅 Book Tasting</button>` }
  ];

  table.innerHTML = headers + rows.map(r => `
    <tr>
      <td><strong>${r.label}</strong></td>
      ${selected.map(v => `<td>${r.fn(v)}</td>`).join('')}
    </tr>
  `).join('');
}

/* ==========================================================================
   5. GALLERY SHOWCASE & LIGHTBOX
   ========================================================================== */
function renderGallery(category) {
  const grid = document.getElementById('galleryGrid');
  const items = category === 'All' ? GALLERY_ITEMS : GALLERY_ITEMS.filter(g => g.category === category);

  grid.innerHTML = items.map(g => `
    <div class="gallery-item ${g.borderClass}" onclick="openGalleryLightbox('${g.id}')">
      <div class="gallery-thumb" style="background:${g.bg};">
        <div style="font-size:2.2rem; margin-bottom:0.4rem;">${g.emoji}</div>
        <span style="background:rgba(255,255,255,0.22); border:1px solid rgba(255,255,255,0.4); padding:0.2rem 0.65rem; border-radius:999px; font-size:0.75rem; width:fit-content; margin-bottom:0.35rem;">${g.category}</span>
        <h4 style="font-size:1.05rem;">${g.title}</h4>
      </div>
      <div class="gallery-body">
        <div style="display:flex; justify-content:space-between; font-size:0.84rem; margin-bottom:0.4rem;">
          <strong>${g.vendor}</strong>
          <span style="color:var(--primary-dark); font-weight:700;">${g.cost}</span>
        </div>
        <p class="muted-small">${g.details}</p>
      </div>
    </div>
  `).join('');
}

function filterGallery(cat, btn) {
  document.querySelectorAll('.gallery-filters .pill').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  renderGallery(cat);
}

function openGalleryLightbox(id) {
  const item = GALLERY_ITEMS.find(g => g.id === id);
  if (!item) return;

  document.getElementById('galleryModalContent').innerHTML = `
    <div style="background:${item.bg}; color:#fff; padding:2rem; border-radius:10px; margin-bottom:1rem; text-align:center;">
      <div style="font-size:3rem;">${item.emoji}</div>
      <h3 style="margin-top:0.5rem;">${item.title}</h3>
      <p style="opacity:0.9;">Catered by ${item.vendor} • ${item.cost}</p>
    </div>
    <p style="margin-bottom:1.25rem; color:var(--secondary);">${item.details}</p>
    <button class="btn btn-primary full-width" onclick="closeModal('galleryModal'); openTastingModal('${item.vendor}');">📅 Request Similar Setup & Tasting</button>
  `;
  document.getElementById('galleryModal').classList.add('open');
}

/* ==========================================================================
   6. CUSTOMER FEEDBACK, CONTACT & MODALS
   ========================================================================== */
function setRating(val) {
  state.selectedRating = val;
  document.querySelectorAll('#starContainer .star').forEach((s, idx) => s.classList.toggle('active', idx < val));
}

function submitFeedback(e) {
  e.preventDefault();
  const newReview = {
    name: document.getElementById('fbName').value.trim(),
    vendor: document.getElementById('fbVendor').value,
    event: document.getElementById('fbEvent').value,
    rating: state.selectedRating,
    comment: document.getElementById('fbComment').value.trim()
  };
  state.reviews.unshift(newReview);
  renderReviews();
  document.getElementById('feedbackForm').reset();
  setRating(5);
  showToast('⭐ Thank you! Your verified review is now live.');
}

function renderReviews() {
  document.getElementById('reviewTotalCount').textContent = state.reviews.length;
  document.getElementById('reviewsList').innerHTML = state.reviews.map(r => `
    <div class="review-card">
      <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.4rem;">
        <strong>${r.name}</strong>
        <span style="color:#f59e0b; font-weight:800;">${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</span>
      </div>
      <div style="font-size:0.8rem; color:var(--primary-dark); font-weight:600; margin:0.2rem 0;">
        ${r.vendor} • ${r.event}
      </div>
      <p style="font-size:0.9rem; color:var(--secondary);">${r.comment}</p>
    </div>
  `).join('');
}

function submitContactForm(e) {
  e.preventDefault();
  const name = document.getElementById('contactName').value.trim();
  document.getElementById('contactForm').reset();
  showToast(`📨 Inquiry received from ${name}! Our concierge will call within 2 hours.`);
}

function openTastingModal(vendorName) {
  document.getElementById('tastingVendorInput').value = vendorName;
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
  document.getElementById('tastingDate').value = tomorrow;
  document.getElementById('tastingModal').classList.add('open');
}

function submitTastingBooking(e) {
  e.preventDefault();
  const vendor = document.getElementById('tastingVendorInput').value;
  const date = document.getElementById('tastingDate').value;
  closeModal('tastingModal');
  showToast(`✅ Tasting booked with ${vendor} for ${date}!`);
}

function saveCurrentQuote() {
  const q = calculateQuoteMetrics(1.0);
  const entry = {
    id: Date.now(),
    date: new Date().toLocaleDateString('en-IN'),
    eventType: state.eventType,
    guests: state.guests,
    perPlate: q.effectivePerPlate,
    total: q.grandTotal,
    dishCount: q.selectedObjects.length
  };
  state.savedQuotes.unshift(entry);
  localStorage.setItem('feastflow_quotes', JSON.stringify(state.savedQuotes));
  updateSavedCount();
  showToast('💾 Quotation saved to your browser list!');
}

function updateSavedCount() {
  document.getElementById('savedCount').textContent = state.savedQuotes.length;
}

function openSavedQuotesModal() {
  const list = document.getElementById('savedQuotesList');
  if (state.savedQuotes.length === 0) {
    list.innerHTML = `<p class="muted-small" style="text-align:center; padding:1.5rem 0;">No saved quotes yet. Click "Save Quote" in the calculator to store estimates.</p>`;
  } else {
    list.innerHTML = state.savedQuotes.map(q => `
      <div style="border:1.5px solid var(--border); border-left:4px solid var(--primary); border-radius:8px; padding:0.85rem; margin-bottom:0.75rem; display:flex; justify-content:space-between; align-items:center;">
        <div>
          <strong>${q.eventType} (${q.guests} Guests)</strong>
          <div class="muted-small">${q.dishCount} items • Saved on ${q.date}</div>
        </div>
        <div class="text-right">
          <div style="font-weight:800; color:var(--primary-dark);">₹${q.total.toLocaleString('en-IN')}</div>
          <div class="muted-small">₹${q.perPlate}/plate</div>
        </div>
      </div>
    `).join('');
  }
  document.getElementById('savedQuotesModal').classList.add('open');
}

function exportQuotePDF() {
  showToast('🖨️ Opening print-ready committee PDF quotation...');
  setTimeout(() => window.print(), 400);
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3200);
}