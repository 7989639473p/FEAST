// FEASTFLOW - corrected single JavaScript file
// All page features are initialized after the HTML has loaded.

document.addEventListener("DOMContentLoaded", () => {
    const $ = (id) => document.getElementById(id);
    const money = (n) => "₹" + Number(n || 0).toLocaleString("en-IN", {
        minimumFractionDigits: 2, maximumFractionDigits: 2
    });
    const safe = (value) => String(value ?? "").replace(/[&<>"']/g, ch => ({
        "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
    }[ch]));

    // ---------------- CATERING QUOTE CALCULATOR ----------------
    const cateringMenu = [
        {name:"Veg Starter", category:"Starters", price:80, diets:["Veg","Jain","Mixed"]},
        {name:"Chicken Starter", category:"Starters", price:120, diets:["Non-Veg","Mixed"]},
        {name:"Paneer Curry", category:"Main Course", price:130, diets:["Veg","Jain","Mixed"]},
        {name:"Chicken Curry", category:"Main Course", price:160, diets:["Non-Veg","Mixed"]},
        {name:"Veg Biryani", category:"Rice", price:110, diets:["Veg","Jain","Mixed"]},
        {name:"Chicken Biryani", category:"Rice", price:150, diets:["Non-Veg","Mixed"]},
        {name:"Roti / Naan", category:"Breads", price:25, diets:["Veg","Jain","Mixed"]},
        {name:"Gulab Jamun", category:"Desserts", price:40, diets:["Veg","Jain","Mixed"]}
    ];

    function renderCateringMenu() {
        const host = $("menuGroups");
        if (!host) return;
        const diet = $("diet")?.value || "Veg";
        const groups = [...new Set(cateringMenu.map(x => x.category))];
        host.innerHTML = groups.map(group => {
            const items = cateringMenu.filter(x => x.category === group && x.diets.includes(diet));
            if (!items.length) return "";
            return `<div class="menu-group"><h4>${group}</h4><div class="menu-options">
                ${items.map(x => `<label class="dish-option">
                    <input type="checkbox" class="catering-dish" data-price="${x.price}" checked>
                    <span>${x.name}</span><b>${money(x.price)}</b>
                </label>`).join("")}
            </div></div>`;
        }).join("");
        host.querySelectorAll(".catering-dish").forEach(el => el.addEventListener("change", calculateQuote));
        calculateQuote();
    }

    function calculateQuote() {
        if (!$("guestCount")) return;
        const guests = Number($("guestCount").value) || 0;
        if ($("guestValue")) $("guestValue").textContent = `${guests} Guests`;
        const perPerson = [...document.querySelectorAll(".catering-dish:checked")]
            .reduce((sum, el) => sum + Number(el.dataset.price), 0);
        const food = perPerson * guests;
        const buffer = $("buffer")?.checked ? food * 0.10 : 0;
        const service = $("service")?.checked ? guests * 25 : 0;
        const discount = food >= 30000 ? food * 0.05 : 0;
        const extra = buffer + service;
        const gst = Math.max(0, food + extra - discount) * 0.05;
        const total = food + extra - discount + gst;
        if ($("foodCost")) $("foodCost").textContent = money(food);
        if ($("discount")) $("discount").textContent = money(discount);
        if ($("extraCost")) $("extraCost").textContent = money(extra);
        if ($("quoteGst")) $("quoteGst").textContent = money(gst);
        if ($("quoteTotal")) $("quoteTotal").textContent = money(total);
        if ($("perPlate")) $("perPlate").textContent = money(guests ? total / guests : 0);
    }

    $("guestCount")?.addEventListener("input", calculateQuote);
    $("diet")?.addEventListener("change", renderCateringMenu);
    $("buffer")?.addEventListener("change", calculateQuote);
    $("service")?.addEventListener("change", calculateQuote);
    renderCateringMenu();

    // ---------------- VENDORS ----------------
    const vendors = [
        {id:1, name:"Spice Garden Caterers", rating:4.8, price:250, specialty:"Traditional Indian food",
         image:"https://images.unsplash.com/photo-1555244162-803834f70033?w=700"},
        {id:2, name:"Royal Feast Events", rating:4.6, price:320, specialty:"Wedding and premium menus",
         image:"https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=700"},
        {id:3, name:"Campus Bites Catering", rating:4.5, price:180, specialty:"College events and parties",
         image:"https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=700"}
    ];

    function renderVendors() {
        const host = $("vendorContainer");
        if (host) host.innerHTML = vendors.map(v => `
            <article class="vendor-card">
                <img src="${v.image}" alt="${safe(v.name)}">
                <h3>${safe(v.name)}</h3><p class="rating">★ ${v.rating} / 5</p>
                <p>${safe(v.specialty)}</p><p><b>${money(v.price)} per plate</b></p>
                <label><input class="compare-vendor" type="checkbox" value="${v.id}"> Compare this vendor</label>
                <button type="button" class="book-vendor" data-id="${v.id}">Book Vendor</button>
            </article>`).join("");
        const select = $("selectedVendor");
        if (select) select.innerHTML = '<option value="">Select Vendor</option>' +
            vendors.map(v => `<option value="${v.id}">${safe(v.name)}</option>`).join("");
    }

    function renderComparison() {
        const host = $("comparison");
        if (!host) return;
        const ids = [...document.querySelectorAll(".compare-vendor:checked")].map(el => Number(el.value));
        const chosen = vendors.filter(v => ids.includes(v.id));
        if (!chosen.length) {
            host.innerHTML = "<p>Select one or more vendors above to compare them.</p>";
            return;
        }
        host.innerHTML = `<table><tr><th>Vendor</th><th>Rating</th><th>Price / Plate</th><th>Specialty</th></tr>
            ${chosen.map(v => `<tr><td>${safe(v.name)}</td><td>★ ${v.rating}</td><td>${money(v.price)}</td><td>${safe(v.specialty)}</td></tr>`).join("")}
            </table>`;
    }
    renderVendors();
    renderComparison();

    // ---------------- GALLERY ----------------
    const gallery = [
        {title:"Buffet Setup", image:"https://images.unsplash.com/photo-1555244162-803834f70033?w=700",
         related:["https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=700","https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=700"]},
        {title:"Indian Feast", image:"https://images.unsplash.com/photo-1547573854-74d2a71d0826?w=700",
         related:["https://images.unsplash.com/photo-1563379091339-03246963d96c?w=700","https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=700"]},
        {title:"Desserts", image:"https://images.unsplash.com/photo-1551024506-0bc0a4e5f1c5?w=700",
         related:["https://images.unsplash.com/photo-1501446529957-6226bd447c46?w=700","https://images.unsplash.com/photo-1488477181946-6428a0291777?w=700"]},
        {title:"Celebration", image:"https://images.unsplash.com/photo-1511795409834-ef04bbd61622?w=700",
         related:["https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=700","https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=700"]}
    ];
    const galleryHost = $("galleryContainer");
    if (galleryHost) {
        galleryHost.innerHTML = gallery.map((g,i) =>
            `<img src="${g.image}" alt="${g.title}" data-gallery="${i}" style="cursor:pointer">`).join("");
        galleryHost.addEventListener("click", e => {
            const img = e.target.closest("[data-gallery]");
            if (!img) return;
            const item = gallery[Number(img.dataset.gallery)];
            $("relatedTitle").textContent = `Related Images: ${item.title}`;
            $("relatedGallery").innerHTML = item.related.map(src => `<img src="${src}" alt="Related ${item.title}">`).join("");
            $("relatedSection").hidden = false;
        });
    }
    $("closeGallery")?.addEventListener("click", () => { $("relatedSection").hidden = true; });

    // ---------------- FOOD MENU + FILTERS ----------------
    const foods = [
        {id:1,name:"Veg Spring Rolls",category:"Starters",price:120,image:"https://images.unsplash.com/photo-1544025162-d76694265947?w=700"},
        {id:2,name:"Paneer Tikka",category:"Starters",price:180,image:"https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=700"},
        {id:3,name:"Chicken 65",category:"Starters",price:200,image:"https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=700"},
        {id:4,name:"Veg Biryani",category:"Main Course",price:220,image:"https://images.unsplash.com/photo-1563379091339-03246963d96c?w=700"},
        {id:5,name:"Paneer Butter Masala",category:"Main Course",price:240,image:"https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=700"},
        {id:6,name:"Chicken Biryani",category:"Main Course",price:260,image:"https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=700"},
        {id:7,name:"Butter Naan",category:"Breads",price:35,image:"https://images.unsplash.com/photo-1600628422019-6a2b9e9f1f4c?w=700"},
        {id:8,name:"Garlic Naan",category:"Breads",price:45,image:"https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=700"},
        {id:9,name:"Gulab Jamun",category:"Desserts",price:60,image:"https://images.unsplash.com/photo-1666190094762-3b3b8f1d3c4a?w=700"},
        {id:10,name:"Ice Cream",category:"Desserts",price:80,image:"https://images.unsplash.com/photo-1501446529957-6226bd447c46?w=700"},
        {id:11,name:"Fresh Lime Soda",category:"Drinks",price:50,image:"https://images.unsplash.com/photo-1513558161293-cdaf765edfd4?w=700"},
        {id:12,name:"Mango Shake",category:"Drinks",price:90,image:"https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=700"}
    ];
    let cart = [];

    function renderMenu(category = "All") {
        const host = $("menuItems");
        if (!host) return;
        const list = category === "All" ? foods : foods.filter(f => f.category === category);
        host.innerHTML = list.length ? list.map(f => `
            <article class="food-card">
                <img src="${f.image}" alt="${safe(f.name)}">
                <h3>${safe(f.name)}</h3><p>${safe(f.category)}</p>
                <p class="food-price">${money(f.price)}</p>
                <button type="button" class="add-to-cart" data-id="${f.id}">Add to Cart</button>
            </article>`).join("") : "<p>No food items found in this category.</p>";
    }
    // Expose this function for the category buttons in the HTML.
    window.filterFood = (category) => renderMenu(category);
    renderMenu();

    function renderCart() {
        const host = $("cartItems");
        if (!host) return;
        let subtotal = 0, count = 0;
        if (!cart.length) {
            host.innerHTML = "<p>Your cart is empty. Add food from the menu above.</p>";
        } else {
            host.innerHTML = cart.map(item => {
                const food = foods.find(f => f.id === item.id);
                if (!food) return "";
                const line = food.price * item.quantity;
                subtotal += line; count += item.quantity;
                return `<div class="cart-row">
                    <strong>${safe(food.name)}</strong><span>${money(food.price)} each</span>
                    <span><button type="button" class="qty-change" data-id="${food.id}" data-step="-1">−</button>
                    ${item.quantity}
                    <button type="button" class="qty-change" data-id="${food.id}" data-step="1">+</button></span>
                    <b>${money(line)}</b>
                    <button type="button" class="remove-item" data-id="${food.id}">Remove</button>
                </div>`;
            }).join("");
        }
        const gst = subtotal * 0.05;
        if ($("subtotal")) $("subtotal").textContent = subtotal.toFixed(2);
        if ($("cartGst")) $("cartGst").textContent = gst.toFixed(2);
        if ($("total")) $("total").textContent = (subtotal + gst).toFixed(2);
        if ($("cartCount")) $("cartCount").textContent = count;
    }
    renderCart();

    // One delegated click handler: works even when food cards are re-rendered by filters.
    document.addEventListener("click", e => {
        const add = e.target.closest(".add-to-cart");
        if (add) {
            const id = Number(add.dataset.id);
            const found = cart.find(x => x.id === id);
            if (found) found.quantity++;
            else cart.push({id, quantity:1});
            renderCart();
            return;
        }
        const qty = e.target.closest(".qty-change");
        if (qty) {
            const id = Number(qty.dataset.id), step = Number(qty.dataset.step);
            const found = cart.find(x => x.id === id);
            if (found) found.quantity += step;
            cart = cart.filter(x => x.quantity > 0);
            renderCart();
            return;
        }
        const remove = e.target.closest(".remove-item");
        if (remove) {
            cart = cart.filter(x => x.id !== Number(remove.dataset.id));
            renderCart();
            return;
        }
        const book = e.target.closest(".book-vendor");
        if (book) {
            if ($("selectedVendor")) $("selectedVendor").value = book.dataset.id;
            $("tasting")?.scrollIntoView({behavior:"smooth"});
        }
    });
    document.addEventListener("change", e => {
        if (e.target.matches(".compare-vendor")) renderComparison();
    });

    // ---------------- CHECKOUT / BILL ----------------
    $("orderForm")?.addEventListener("submit", e => {
        e.preventDefault();
        if (!cart.length) { alert("Please add food to your cart first."); return; }
        const name = $("orderCustomerName").value.trim();
        const phone = $("phone").value.trim();
        const email = $("email").value.trim();
        const date = $("eventDate").value;
        const guests = $("guests").value;
        const eventType = $("orderEventType").value;
        const address = $("address").value.trim();
        const instructions = $("instructions").value.trim();
        let subtotal = 0;
        const rows = cart.map(item => {
            const f = foods.find(x => x.id === item.id);
            const amount = f.price * item.quantity; subtotal += amount;
            return `<tr><td>${safe(f.name)}</td><td>${item.quantity}</td><td>${money(f.price)}</td><td>${money(amount)}</td></tr>`;
        }).join("");
        const gst = subtotal * 0.05, total = subtotal + gst;
        $("bill").innerHTML = `<h2>FeastFlow Order Bill</h2><h3>Order received!</h3>
            <p><b>Order ID:</b> FF${Date.now()}</p><hr>
            <p><b>Name:</b> ${safe(name)}</p><p><b>Phone:</b> ${safe(phone)}</p>
            <p><b>Email:</b> ${safe(email)}</p><p><b>Event:</b> ${safe(eventType)}</p>
            <p><b>Date:</b> ${safe(date)}</p><p><b>Guests:</b> ${safe(guests)}</p>
            <p><b>Location:</b> ${safe(address)}</p><p><b>Instructions:</b> ${safe(instructions || "None")}</p>
            <table><tr><th>Food</th><th>Qty</th><th>Price</th><th>Amount</th></tr>${rows}</table>
            <h3>Subtotal: ${money(subtotal)}</h3><h3>GST (5%): ${money(gst)}</h3>
            <h2>Grand Total: ${money(total)}</h2>
            <button type="button" onclick="window.print()">Print / Save PDF</button>`;
        cart = []; renderCart(); e.target.reset();
        $("bill").scrollIntoView({behavior:"smooth"});
    });

    // ---------------- REVIEWS ----------------
    let reviews = [
        {name:"Ananya", rating:5, message:"Great food and smooth event planning!"},
        {name:"Rahul", rating:4, message:"The menu and quotation were very helpful."}
    ];
    function renderReviews() {
        if (!$("reviewContainer")) return;
        $("reviewContainer").innerHTML = reviews.map(r => `
            <div class="review-card"><h3>${safe(r.name)}</h3>
            <div class="stars">${"★".repeat(r.rating)}${"☆".repeat(5-r.rating)}</div>
            <p>${safe(r.message)}</p></div>`).join("");
    }
    renderReviews();
    $("feedbackForm")?.addEventListener("submit", e => {
        e.preventDefault();
        reviews.unshift({name:$("reviewName").value.trim(), rating:Number($("reviewRating").value),
            message:$("reviewMessage").value.trim()});
        renderReviews(); e.target.reset(); alert("Thank you for your feedback!");
    });

    // ---------------- TASTING / CONTACT ----------------
    $("tastingForm")?.addEventListener("submit", e => {
        e.preventDefault();
        const id = Number($("selectedVendor").value);
        const vendor = vendors.find(v => v.id === id);
        if (!vendor) { alert("Please select a vendor."); return; }
        alert(`Your tasting request for ${vendor.name} has been recorded in this demo.`);
        e.target.reset();
    });
    $("contactForm")?.addEventListener("submit", e => {
        e.preventDefault(); alert("Thank you! Your message has been recorded in this demo."); e.target.reset();
    });

    console.log("FeastFlow loaded: menu, vendors, cart and forms are ready.");
});
